/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package testmeshnetwork_visual;

/**
 *
 * @author NET-0011
 */
public class TestMeshNetwork_Visual {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Frame_Test f = new Frame_Test();
        f.setVisible(true);
    }
    
}
